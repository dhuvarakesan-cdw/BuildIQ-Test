export interface IOptions {
  allowIcannDomains: boolean;
  allowPrivateDomains: boolean;
  detectIp: boolean;
  // Detect RFC 6761 / IANA special-use domains and expose the result as
  // `isSpecialUse` on `parse()`. Off by default so the common path stays
  // allocation-free with no extra work; enable it to populate the field.
  detectSpecialUse: boolean;
  // Extra public suffix rules, in PSL syntax, per section (default: null)
  extraSuffixes: {
    icann?: readonly string[];
    private?: readonly string[];
  } | null;
  extractHostname: boolean;
  mixedInputs: boolean;
  validHosts: string[] | null;
  validateHostname: boolean;
}

function setDefaultsImpl({
  allowIcannDomains = true,
  allowPrivateDomains = false,
  detectIp = true,
  detectSpecialUse = false,
  extraSuffixes = null,
  extractHostname = true,
  mixedInputs = true,
  validHosts = null,
  validateHostname = true,
}: Partial<IOptions>): IOptions {
  return {
    allowIcannDomains,
    allowPrivateDomains,
    detectIp,
    detectSpecialUse,
    extraSuffixes,
    extractHostname,
    mixedInputs,
    validHosts,
    validateHostname,
  };
}

const DEFAULT_OPTIONS = /*@__INLINE__*/ setDefaultsImpl({});

export function setDefaults(options?: Partial<IOptions> | null): IOptions {
  // `null` as well: untyped callers pass it to mean "no options".
  if (options === undefined || options === null) {
    return DEFAULT_OPTIONS;
  }

  return /*@__INLINE__*/ setDefaultsImpl(options);
}
